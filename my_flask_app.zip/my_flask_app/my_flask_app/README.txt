1. Install Python if you haven't already.
2. Go to this folder (my_flask_app).
3. (Recommended) Create a virtual environment:
      python -m venv venv
      venv\Scripts\activate        (Windows)
      source venv/bin/activate     (Mac/Linux)
4. Install Flask:
      pip install flask
5. Run the app:
      python app.py
6. Open http://127.0.0.1:5000 in your browser.

Works pages: toUpperCase, Circle, Triangle, Linked List, Stack, Postfix,
Queue (queues.py), Deque (queues.py), Sorting research (sorting.py),
Binary Tree (binarytree.py).
