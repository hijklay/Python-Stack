import math
from flask import Flask, render_template, request
from linkedlist import LinkedList
from stack import Stack, infix_to_postfix
from queues import Queue, Deque
import sorting

app = Flask(__name__)
my_list = LinkedList()  
my_stack = Stack()      
my_queue = Queue()
my_deque = Deque()


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/profile")
def profile():
    return render_template("profile.html")


@app.route("/works")
def works():
    return render_template("works.html")


@app.route("/contact")
def contact():
    return render_template("contact.html")

@app.route("/works/touppercase", methods=["GET", "POST"])
def to_uppercase():
    result = None
    if request.method == "POST":
        text = request.form.get("text", "")
        result = text.upper()
    return render_template("touppercase.html", result=result)


@app.route("/works/area/circle", methods=["GET", "POST"])
def acircle():
    result = None
    error = None
    if request.method == "POST":
        try:
            radius = float(request.form.get("radius", ""))
            if radius < 0:
                error = "Radius cannot be negative."
            else:
                result = round(math.pi * radius ** 2, 2)
        except ValueError:
            error = "Please enter a valid number."
    return render_template("circle.html", result=result, error=error)


@app.route("/works/area/triangle", methods=["GET", "POST"])
def atriangle():
    result = None
    error = None
    if request.method == "POST":
        try:
            base = float(request.form.get("base", ""))
            height = float(request.form.get("height", ""))
            if base < 0 or height < 0:
                error = "Base and height cannot be negative."
            else:
                result = round(0.5 * base * height, 2)
        except ValueError:
            error = "Please enter valid numbers."
    return render_template("triangle.html", result=result, error=error)


@app.route("/works/linked-list", methods=["GET", "POST"])
def linked_list():
    message = None
    if request.method == "POST":
        action = request.form.get("action")
        value = request.form.get("value", "").strip()
        after = request.form.get("after", "").strip()

        # actions that need no value
        if action == "clear":
            my_list.clear()
            message = "List cleared."
        elif action == "remove_beginning":
            removed = my_list.remove_beginning()
            message = (f"Removed '{removed}' from the beginning."
                       if removed is not None else "The list is empty.")
        elif action == "remove_at_end":
            removed = my_list.remove_at_end()
            message = (f"Removed '{removed}' from the end."
                       if removed is not None else "The list is empty.")
        # actions that need a value
        elif not value:
            message = "Please enter a value."
        elif action == "insert_head":
            my_list.insert_at_beginning(value)
            message = f"Inserted '{value}' at the beginning."
        elif action == "insert_middle":
            pos = my_list.insert_middle(value)
            message = f"Inserted '{value}' in the middle (position {pos})."
        elif action == "insert_tail":
            my_list.insert_at_end(value)
            message = f"Inserted '{value}' at the end."
        elif action == "insert_after":
            if not after:
                message = "Please enter the node to insert after."
            elif my_list.insert_after(after, value) is None:
                message = f"'{after}' not found (returned None)."
            else:
                message = f"Inserted '{value}' after '{after}'."
        elif action == "remove_at":
            removed = my_list.remove_at(value)
            message = (f"Removed '{removed}'."
                       if removed is not None else f"'{value}' not found (returned None).")
        elif action == "search":
            found = my_list.search(value)
            if found:
                message = f"True: '{value}' is at position {my_list.position(value)}."
            else:
                message = f"False: '{value}' not found."
    return render_template("linked_list.html", items=my_list.to_list(), message=message)


@app.route("/works/stack", methods=["GET", "POST"])
def stack_page():
    message = None
    if request.method == "POST":
        action = request.form.get("action")
        value = request.form.get("value", "").strip()
        if action == "clear":
            my_stack.clear()
            message = "Stack cleared."
        elif action == "pop":
            popped = my_stack.pop()
            message = (f"Popped '{popped}'." if popped is not None
                       else "The stack is empty (returned None).")
        elif action == "peek":
            top = my_stack.peek()
            message = (f"Top of the stack: '{top}'." if top is not None
                       else "The stack is empty (returned None).")
        elif not value:
            message = "Please enter a value."
        elif action == "push":
            my_stack.push(value)
            message = f"Pushed '{value}' onto the stack."
    return render_template("stack.html", items=my_stack.to_list(), message=message)


@app.route("/works/postfix", methods=["GET", "POST"])
def postfix():
    expression = ""
    result = None
    steps = []
    error = None
    if request.method == "POST":
        expression = request.form.get("expression", "").strip()
        try:
            result, steps = infix_to_postfix(expression)
        except ValueError as e:
            error = str(e)
    return render_template("postfix.html", expression=expression,
                           result=result, steps=steps, error=error)


queue_log = []   # step-by-step history shown in the trace table
deque_log = []


def record(log, op, action, items):
    """Add one row to a trace table: the operation, what happened, and the structure afterwards."""
    log.append({"op": op, "action": action,
                "state": " ".join(str(x) for x in items) or "(empty)",
                "size": len(items)})
    del log[:-100]          # keep the last 100 steps


@app.route("/works/queue", methods=["GET", "POST"])
def queue_page():
    message = None
    if request.method == "POST":
        action = request.form.get("action")
        value = request.form.get("value", "").strip()
        if action == "clear":
            my_queue.clear()
            queue_log.clear()
            message = "Queue cleared."
        elif action == "dequeue":
            removed = my_queue.dequeue()
            message = (f"Dequeued '{removed}' from the front." if removed is not None
                       else "The queue is empty (returned None).")
            record(queue_log, "dequeue()",
                   f"Remove '{removed}' from the front" if removed is not None
                   else "Queue is empty, returned None", my_queue.to_list())
        elif action == "peek":
            front = my_queue.peek()
            message = (f"Front of the queue: '{front}'." if front is not None
                       else "The queue is empty (returned None).")
            record(queue_log, "peek()",
                   f"Read '{front}' at the front, nothing removed" if front is not None
                   else "Queue is empty, returned None", my_queue.to_list())
        elif not value:
            message = "Please enter a value."
        elif action == "enqueue":
            my_queue.enqueue(value)
            message = f"Enqueued '{value}' at the rear."
            record(queue_log, f"enqueue({value})", f"Add '{value}' at the rear", my_queue.to_list())
    return render_template("queue.html", items=my_queue.to_list(), message=message, steps=queue_log)


@app.route("/works/deque", methods=["GET", "POST"])
def deque_page():
    message = None
    if request.method == "POST":
        action = request.form.get("action")
        value = request.form.get("value", "").strip()
        if action == "clear":
            my_deque.clear()
            deque_log.clear()
            message = "Deque cleared."
        elif action in ("remove_front", "remove_rear"):
            removed = my_deque.remove_front() if action == "remove_front" else my_deque.remove_rear()
            end = "front" if action == "remove_front" else "rear"
            message = (f"Removed '{removed}' from the {end}." if removed is not None
                       else "The deque is empty (returned None).")
            record(deque_log, f"remove_{end}()",
                   f"Remove '{removed}' from the {end}" if removed is not None
                   else "Deque is empty, returned None", my_deque.to_list())
        elif action in ("peek_front", "peek_rear"):
            item = my_deque.peek_front() if action == "peek_front" else my_deque.peek_rear()
            end = "front" if action == "peek_front" else "rear"
            message = (f"The {end} item is '{item}'." if item is not None
                       else "The deque is empty (returned None).")
            record(deque_log, f"peek_{end}()",
                   f"Read '{item}' at the {end}, nothing removed" if item is not None
                   else "Deque is empty, returned None", my_deque.to_list())
        elif not value:
            message = "Please enter a value."
        elif action == "add_front":
            my_deque.add_front(value)
            message = f"Added '{value}' at the front."
            record(deque_log, f"add_front({value})", f"Add '{value}' at the front", my_deque.to_list())
        elif action == "add_rear":
            my_deque.add_rear(value)
            message = f"Added '{value}' at the rear."
            record(deque_log, f"add_rear({value})", f"Add '{value}' at the rear", my_deque.to_list())
    return render_template("deque.html", items=my_deque.to_list(), message=message, steps=deque_log)


@app.route("/works/sorting", methods=["GET", "POST"])
def sorting_page():
    values, algorithm, outcome, error = "", "bubble", None, None
    if request.method == "POST":
        values = request.form.get("values", "").strip()
        algorithm = request.form.get("algorithm", "bubble")
        try:
            outcome = sorting.run(algorithm, values)
        except ValueError as e:
            error = str(e)
    return render_template("sorting.html", values=values, algorithm=algorithm,
                           outcome=outcome, error=error, info=sorting.ALGORITHMS)


if __name__ == "__main__":
    app.run(debug=True)
