import math
from flask import Flask, render_template, request
from linkedlist import LinkedList

app = Flask(__name__)
my_list = LinkedList()  


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/profile")
def profile():
    return render_template("profile.html")


@app.route("/works")
def works():
    return render_template("works.html")


@app.route("/contact")
def contact():
    return render_template("contact.html")


@app.route("/works/touppercase", methods=["GET", "POST"])
def to_uppercase():
    result = None
    if request.method == "POST":
        text = request.form.get("text", "")
        result = text.upper()
    return render_template("touppercase.html", result=result)


@app.route("/works/area/circle", methods=["GET", "POST"])
def acircle():
    result = None
    error = None
    if request.method == "POST":
        try:
            radius = float(request.form.get("radius", ""))
            if radius < 0:
                error = "Radius cannot be negative."
            else:
                result = round(math.pi * radius ** 2, 2)
        except ValueError:
            error = "Please enter a valid number."
    return render_template("circle.html", result=result, error=error)


@app.route("/works/area/triangle", methods=["GET", "POST"])
def atriangle():
    result = None
    error = None
    if request.method == "POST":
        try:
            base = float(request.form.get("base", ""))
            height = float(request.form.get("height", ""))
            if base < 0 or height < 0:
                error = "Base and height cannot be negative."
            else:
                result = round(0.5 * base * height, 2)
        except ValueError:
            error = "Please enter valid numbers."
    return render_template("triangle.html", result=result, error=error)


@app.route("/works/linked-list", methods=["GET", "POST"])
def linked_list():
    message = None
    if request.method == "POST":
        action = request.form.get("action")
        value = request.form.get("value", "").strip()
        after = request.form.get("after", "").strip()

        if action == "clear":
            my_list.clear()
            message = "List cleared."
        elif action == "remove_beginning":
            removed = my_list.remove_beginning()
            message = (f"Removed '{removed}' from the beginning."
                       if removed is not None else "The list is empty.")
        elif action == "remove_at_end":
            removed = my_list.remove_at_end()
            message = (f"Removed '{removed}' from the end."
                       if removed is not None else "The list is empty.")
        elif not value:
            message = "Please enter a value."
        elif action == "insert_head":
            my_list.insert_at_beginning(value)
            message = f"Inserted '{value}' at the beginning."
        elif action == "insert_middle":
            pos = my_list.insert_middle(value)
            message = f"Inserted '{value}' in the middle (position {pos})."
        elif action == "insert_tail":
            my_list.insert_at_end(value)
            message = f"Inserted '{value}' at the end."
        elif action == "insert_after":
            if not after:
                message = "Please enter the node to insert after."
            elif my_list.insert_after(after, value) is None:
                message = f"'{after}' not found (returned None)."
            else:
                message = f"Inserted '{value}' after '{after}'."
        elif action == "remove_at":
            removed = my_list.remove_at(value)
            message = (f"Removed '{removed}'."
                       if removed is not None else f"'{value}' not found (returned None).")
        elif action == "search":
            found = my_list.search(value)
            if found:
                message = f"True: '{value}' is at position {my_list.position(value)}."
            else:
                message = f"False: '{value}' not found."
    return render_template("linked_list.html", items=my_list.to_list(), message=message)


if __name__ == "__main__":
    app.run(debug=True)
