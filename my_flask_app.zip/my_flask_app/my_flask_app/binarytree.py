"""Binary tree for the Trees lab: insert, traverse, search and delete."""
from collections import deque

MAX_NODES = 63   # keeps the drawing readable and recursion shallow


class Node:
    """A node in a binary tree."""
    def __init__(self, value, left=None, right=None):
        self.value = value
        self.left = left
        self.right = right


class BinaryTree:
    """A binary tree data structure."""
    def __init__(self, root_value=None):
        self.root = Node(root_value) if root_value is not None else None

    # ---------- adding ----------
    def insert_left(self, current_node, value):
        """Insert a node as the left child of current_node (old left child moves down)."""
        if current_node.left is None:
            current_node.left = Node(value)
        else:
            new_node = Node(value)
            new_node.left = current_node.left
            current_node.left = new_node

    def insert_right(self, current_node, value):
        """Insert a node as the right child of current_node (old right child moves down)."""
        if current_node.right is None:
            current_node.right = Node(value)
        else:
            new_node = Node(value)
            new_node.right = current_node.right
            current_node.right = new_node

    # ---------- traversals ----------
    def preorder_traversal(self, start, traversal):
        """root, left, right"""
        if start:
            traversal += str(start.value) + " "
            traversal = self.preorder_traversal(start.left, traversal)
            traversal = self.preorder_traversal(start.right, traversal)
        return traversal

    def inorder_traversal(self, start, traversal):
        """left, root, right"""
        if start:
            traversal = self.inorder_traversal(start.left, traversal)
            traversal += str(start.value) + " "
            traversal = self.inorder_traversal(start.right, traversal)
        return traversal

    def post_traversal(self, start, traversal):
        """left, right, root"""
        if start:
            traversal = self.post_traversal(start.left, traversal)
            traversal = self.post_traversal(start.right, traversal)
            traversal += str(start.value) + " "
        return traversal

    postorder_traversal = post_traversal   # alias

    # ---------- searching ----------
    def search(self, root, key):
        """Return the first node (preorder) whose value equals key, or None.
        This is not a binary SEARCH tree, so both subtrees may have to be checked."""
        if root is None:
            return None
        if root.value == key:
            return root
        found = self.search(root.left, key)
        if found is not None:
            return found
        return self.search(root.right, key)

    # ---------- deleting ----------
    def deepest(self, root):
        """Return the last node in level order (the deepest, right-most node)."""
        if root is None:
            return None
        last, queue = root, deque([root])
        while queue:
            last = queue.popleft()
            if last.left:
                queue.append(last.left)
            if last.right:
                queue.append(last.right)
        return last

    def delete_node(self, root, key):
        """Delete the first node holding key and return the (possibly new) root.

        1. Find the node to delete and the deepest, right-most node (and its parent).
        2. Copy the deepest node's value into the node to delete.
        3. Cut the deepest node off. It is always a leaf, so no subtree is lost.
        """
        if root is None:
            return None
        if root.left is None and root.right is None:       # tree with one node
            return None if root.value == key else root

        target, last, last_parent = None, None, None
        queue = deque([(root, None)])
        while queue:
            node, parent = queue.popleft()
            if target is None and node.value == key:
                target = node
            last, last_parent = node, parent
            if node.left:
                queue.append((node.left, node))
            if node.right:
                queue.append((node.right, node))

        if target is None:                                  # key not in the tree
            return root

        target.value = last.value
        if last_parent.right is last:
            last_parent.right = None
        else:
            last_parent.left = None
        return root

    # ---------- helpers for the web page ----------
    def count(self, node="root"):
        node = self.root if node == "root" else node
        return 0 if node is None else 1 + self.count(node.left) + self.count(node.right)

    def depth_of(self, target):
        """Level of a node, starting at 1 for the root (as on the slides)."""
        queue = deque([(self.root, 1)]) if self.root else deque()
        while queue:
            node, d = queue.popleft()
            if node is target:
                return d
            for child in (node.left, node.right):
                if child:
                    queue.append((child, d + 1))
        return 0

    def height(self, node="root"):
        node = self.root if node == "root" else node
        return 0 if node is None else 1 + max(self.height(node.left), self.height(node.right))

    def layout(self):
        """Positions for drawing: x = inorder column, y = level. Returns (nodes, edges)."""
        nodes, edges, col = [], [], [0]

        def walk(node, depth):
            if node is None:
                return None
            left = walk(node.left, depth + 1)
            idx = len(nodes)
            nodes.append({"id": id(node), "value": str(node.value),
                          "col": col[0], "depth": depth})
            col[0] += 1
            right = walk(node.right, depth + 1)
            for child in (left, right):
                if child is not None:
                    edges.append((idx, child))
            return idx

        walk(self.root, 0)
        return nodes, edges

    def clear(self):
        self.root = None


def sample_tree():
    """The tree from the slides: R / A B / C D E F / G."""
    tree = BinaryTree("R")
    tree.insert_left(tree.root, "A")
    tree.insert_right(tree.root, "B")
    tree.insert_left(tree.root.left, "C")
    tree.insert_right(tree.root.left, "D")
    tree.insert_left(tree.root.right, "E")
    tree.insert_right(tree.root.right, "F")
    tree.insert_left(tree.root.right.right, "G")
    return tree
