class Node:
    def __init__(self, data):
        self.data = data
        self.next = None


class LinkedList:
    def __init__(self):
        self.head = None
        self.tail = None

    def insert_at_beginning(self, data):
        new_node = Node(data)
        if self.head:
            new_node.next = self.head
            self.head = new_node
        else:
            self.tail = new_node
            self.head = new_node

    def insert_at_end(self, data):
        new_node = Node(data)
        if self.head:
            self.tail.next = new_node
            self.tail = new_node
        else:
            self.head = new_node
            self.tail = new_node

    def insert_after(self, nodedata, data):
        current_node = self.head
        while current_node:
            if current_node.data == nodedata:
                new_node = Node(data)
                new_node.next = current_node.next
                current_node.next = new_node
                if current_node is self.tail:  
                    self.tail = new_node
                return data
            current_node = current_node.next
        return None

    def insert_middle(self, data):
        index = (len(self) + 1) // 2
        if index == 0:
            self.insert_at_beginning(data)
            return 0
        cur = self.head
        for _ in range(index - 1):
            cur = cur.next
        new_node = Node(data)
        new_node.next = cur.next
        cur.next = new_node
        if cur is self.tail:
            self.tail = new_node
        return index

    def remove_beginning(self):
        if not self.head:
            return None
        removed = self.head.data
        self.head = self.head.next
        if self.head is None:       
            self.tail = None
        return removed

    def remove_at_end(self):
        if not self.head:
            return None
        removed = self.tail.data
        if self.head is self.tail: 
            self.head = None
            self.tail = None
            return removed
        current_node = self.head
        while current_node.next is not self.tail:
            current_node = current_node.next
        current_node.next = None
        self.tail = current_node
        return removed

    def remove_at(self, data):
        current_node = self.head
        previous = None
        while current_node:
            if current_node.data == data:
                if previous is None:                 
                    self.head = current_node.next
                else:
                    previous.next = current_node.next
                if current_node is self.tail:        
                    self.tail = previous
                return current_node.data
            previous = current_node
            current_node = current_node.next
        return None

    def search(self, data):
        current_node = self.head
        while current_node:
            if current_node.data == data:
                return True
            current_node = current_node.next
        return False

    def position(self, data):
        current_node, i = self.head, 0
        while current_node:
            if current_node.data == data:
                return i
            current_node, i = current_node.next, i + 1
        return -1

    def __len__(self):
        count, cur = 0, self.head
        while cur:
            count += 1
            cur = cur.next
        return count

    def clear(self):
        self.head = None
        self.tail = None

    def to_list(self):
        items, cur = [], self.head
        while cur:
            items.append(cur.data)
            cur = cur.next
        return items
