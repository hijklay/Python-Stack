class Node:
    def __init__(self, data):
        self.data = data
        self.next = None


class Queue:
    """FIFO queue built on a singly linked list (front = head, rear = tail)."""

    def __init__(self):
        self.front = None
        self.rear = None

    def is_empty(self):
        return self.front is None

    def enqueue(self, data):
        new_node = Node(data)
        if self.rear:
            self.rear.next = new_node
        else:
            self.front = new_node
        self.rear = new_node

    def dequeue(self):
        if self.front is None:
            return None
        removed = self.front
        self.front = removed.next
        if self.front is None:
            self.rear = None
        removed.next = None
        return removed.data

    def peek(self):
        return self.front.data if self.front else None

    def size(self):
        return len(self.to_list())

    def __len__(self):
        return self.size()

    def clear(self):
        self.front = None
        self.rear = None

    def to_list(self):
        items, cur = [], self.front
        while cur:
            items.append(cur.data)
            cur = cur.next
        return items


class DNode:
    def __init__(self, data):
        self.data = data
        self.prev = None
        self.next = None


class Deque:
    """Double-ended queue built on a doubly linked list."""

    def __init__(self):
        self.front = None
        self.rear = None

    def is_empty(self):
        return self.front is None

    def add_front(self, data):
        new_node = DNode(data)
        if self.front:
            new_node.next = self.front
            self.front.prev = new_node
        else:
            self.rear = new_node
        self.front = new_node

    def add_rear(self, data):
        new_node = DNode(data)
        if self.rear:
            new_node.prev = self.rear
            self.rear.next = new_node
        else:
            self.front = new_node
        self.rear = new_node

    def remove_front(self):
        if self.front is None:
            return None
        removed = self.front
        self.front = removed.next
        if self.front:
            self.front.prev = None
        else:
            self.rear = None
        removed.next = None
        return removed.data

    def remove_rear(self):
        if self.rear is None:
            return None
        removed = self.rear
        self.rear = removed.prev
        if self.rear:
            self.rear.next = None
        else:
            self.front = None
        removed.prev = None
        return removed.data

    def __len__(self):
        return len(self.to_list())

    def peek_front(self):
        return self.front.data if self.front else None

    def peek_rear(self):
        return self.rear.data if self.rear else None

    def clear(self):
        self.front = None
        self.rear = None

    def to_list(self):
        items, cur = [], self.front
        while cur:
            items.append(cur.data)
            cur = cur.next
        return items


class QueueUsingDeque:
    """Same Queue interface, but backed by Python's collections.deque
    (appendleft/popleft are O(1)), the 'queue using deque' idea from the lecture."""

    def __init__(self):
        from collections import deque
        self._items = deque()

    def is_empty(self):
        return not self._items

    def enqueue(self, data):
        self._items.append(data)

    def dequeue(self):
        return self._items.popleft() if self._items else None

    def peek(self):
        return self._items[0] if self._items else None

    def size(self):
        return len(self._items)

    def __len__(self):
        return len(self._items)

    def clear(self):
        self._items.clear()

    def to_list(self):
        return list(self._items)
