"""Sorting algorithms for Lab #7, each returning (sorted_list, comparisons, swaps, steps)."""
import time

# Research notes shown on the page
ALGORITHMS = {
    "bubble": {
        "name": "Bubble Sort",
        "idea": "Compare each pair of adjacent elements and swap them if they are not in order. Repeat the passes until no swaps are needed. The largest value 'bubbles' to the end on each pass.",
        "best": "O(n)", "average": "O(n^2)", "worst": "O(n^2)", "space": "O(1)",
        "stable": "Yes", "use": "Small datasets and educational purposes, to teach the concept of sorting.",
    },
    "selection": {
        "name": "Selection Sort",
        "idea": "Split the list into a sorted part (left) and an unsorted part (right). On each pass, find the lowest value in the unsorted part and swap it with the first unsorted element.",
        "best": "O(n^2)", "average": "O(n^2)", "worst": "O(n^2)", "space": "O(1)",
        "stable": "No", "use": "Not for large datasets, but good when memory is limited or when minimizing the number of swaps matters.",
    },
    "insertion": {
        "name": "Insertion Sort",
        "idea": "Build the final sorted list one item at a time: take each element, find the spot where it belongs in the sorted part, and insert it there (like sorting playing cards in your hand).",
        "best": "O(n)", "average": "O(n^2)", "worst": "O(n^2)", "space": "O(1)",
        "stable": "Yes", "use": "When the list is mostly sorted (few misplaced elements), the list is small, or low memory usage is a priority.",
    },
    "merge": {
        "name": "Merge Sort",
        "idea": "A divide-and-conquer algorithm: split the list into halves until each part has one element (trivially sorted), then merge the sorted halves back together.",
        "best": "O(n log n)", "average": "O(n log n)", "worst": "O(n log n)", "space": "O(n)",
        "stable": "Yes", "use": "Large datasets, when a stable sort is needed, and when there is enough memory for the extra space used in merging.",
    },
    "quick": {
        "name": "Quick Sort",
        "idea": "A divide-and-conquer algorithm (C.A.R. Hoare, 1960): pick a pivot, partition the other elements into those less than and greater than the pivot, then sort each partition recursively. It works in place.",
        "best": "O(n log n)", "average": "O(n log n)", "worst": "O(n^2)", "space": "O(log n)",
        "stable": "No", "use": "When average O(n log n) time is expected and space efficiency is a priority (in place, little extra memory). Not stable in its standard form.",
    },
}


def _key(v):
    """Sort numbers numerically and anything else as text."""
    return (0, v) if isinstance(v, (int, float)) else (1, str(v).lower())


def bubble_sort(data):
    a, cmp, swp, steps = list(data), 0, 0, []
    n = len(a)
    for i in range(n - 1):
        swapped = False
        for j in range(n - 1 - i):
            cmp += 1
            if _key(a[j]) > _key(a[j + 1]):
                a[j], a[j + 1] = a[j + 1], a[j]
                swp += 1
                swapped = True
        steps.append(f"Pass {i + 1}: {a}")
        if not swapped:
            break
    return a, cmp, swp, steps


def selection_sort(data):
    a, cmp, swp, steps = list(data), 0, 0, []
    n = len(a)
    for i in range(n - 1):
        m = i
        for j in range(i + 1, n):
            cmp += 1
            if _key(a[j]) < _key(a[m]):
                m = j
        if m != i:
            a[i], a[m] = a[m], a[i]
            swp += 1
        steps.append(f"Pass {i + 1}: {a}")
    return a, cmp, swp, steps


def insertion_sort(data):
    a, cmp, swp, steps = list(data), 0, 0, []
    for i in range(1, len(a)):
        cur, j = a[i], i - 1
        while j >= 0:
            cmp += 1
            if _key(a[j]) > _key(cur):
                a[j + 1] = a[j]
                swp += 1
                j -= 1
            else:
                break
        a[j + 1] = cur
        steps.append(f"Insert {cur}: {a}")
    return a, cmp, swp, steps


def merge_sort(data):
    cmp = swp = 0
    steps = []

    def sort(a):
        nonlocal cmp, swp
        if len(a) <= 1:
            return a
        mid = len(a) // 2
        steps.append(f"Split {a} -> {a[:mid]} | {a[mid:]}")
        left, right = sort(a[:mid]), sort(a[mid:])
        merged, i, j = [], 0, 0
        while i < len(left) and j < len(right):
            cmp += 1
            if _key(left[i]) <= _key(right[j]):
                merged.append(left[i]); i += 1
            else:
                merged.append(right[j]); j += 1
                swp += 1
        merged += left[i:] + right[j:]
        steps.append(f"Merge {left} + {right} -> {merged}")
        return merged

    return sort(list(data)), cmp, swp, steps


def quick_sort(data):
    """In-place quick sort (middle pivot, Lomuto partition).
    Recursing into the smaller part first keeps the extra space at O(log n)."""
    a, steps = list(data), []
    stats = {"cmp": 0, "swp": 0}

    def partition(lo, hi):
        mid = (lo + hi) // 2
        if mid != hi:
            a[mid], a[hi] = a[hi], a[mid]
            stats["swp"] += 1
        pivot, store = a[hi], lo
        for i in range(lo, hi):
            stats["cmp"] += 1
            if _key(a[i]) < _key(pivot):
                if i != store:
                    a[i], a[store] = a[store], a[i]
                    stats["swp"] += 1
                store += 1
        if store != hi:
            a[store], a[hi] = a[hi], a[store]
            stats["swp"] += 1
        steps.append(f"Pivot {pivot}: {a}")
        return store

    def sort(lo, hi):
        while lo < hi:
            p = partition(lo, hi)
            if p - lo < hi - p:
                sort(lo, p - 1)
                lo = p + 1
            else:
                sort(p + 1, hi)
                hi = p - 1

    sort(0, len(a) - 1)
    return a, stats["cmp"], stats["swp"], steps


FUNCTIONS = {"bubble": bubble_sort, "selection": selection_sort,
             "insertion": insertion_sort, "merge": merge_sort, "quick": quick_sort}


def parse_values(text):
    """'5, 3, 8' or '5 3 8' -> [5, 3, 8]. Numbers stay numbers, the rest stay text."""
    parts = [p for p in text.replace(",", " ").split() if p]
    if not parts:
        raise ValueError("Please enter some values.")
    if len(parts) > 50:
        raise ValueError("Please enter 50 values or fewer.")
    values = []
    for p in parts:
        try:
            values.append(int(p))
        except ValueError:
            try:
                values.append(float(p))
            except ValueError:
                values.append(p)
    return values


def run(algorithm, text):
    if algorithm not in FUNCTIONS:
        raise ValueError("Unknown algorithm.")
    values = parse_values(text)
    start = time.perf_counter()
    result, cmp, swp, steps = FUNCTIONS[algorithm](values)
    micro = round((time.perf_counter() - start) * 1_000_000, 1)
    return {"input": values, "output": result, "comparisons": cmp,
            "swaps": swp, "steps": steps, "micro": micro}
