import re


class Node:
    def __init__(self, data):
        self.data = data
        self.next = None


class Stack:
    def __init__(self):
        self.top = None

    def is_empty(self):
        return self.top is None

    def push(self, data):
        new_node = Node(data)
        if self.top:
            new_node.next = self.top
        self.top = new_node

    def pop(self):
        if self.top is None:
            return None
        popped_node = self.top
        self.top = self.top.next
        popped_node.next = None
        return popped_node.data

    def peek(self):
        if self.top:
            return self.top.data
        return None

    def clear(self):
        self.top = None

    def to_list(self):
        items, cur = [], self.top
        while cur:
            items.append(cur.data)
            cur = cur.next
        return items


#infix to postfix (shunting yard)
PRECEDENCE = {"^": 3, "*": 2, "/": 2, "+": 1, "-": 1}
RIGHT_ASSOCIATIVE = {"^"}


def tokenize(expression):
    tokens = re.findall(r"[A-Za-z0-9.]+|[-+*/^()]|\S", expression)
    for t in tokens:
        if not (re.fullmatch(r"[A-Za-z0-9.]+", t) or t in PRECEDENCE or t in "()"):
            raise ValueError(f"Invalid character: '{t}'")
    return tokens


def infix_to_postfix(expression):
    tokens = tokenize(expression)
    if not tokens:
        raise ValueError("Please enter an expression.")

    ops = Stack()    
    output = ""        
    steps = []

    def add(token):
        nonlocal output
        output = (output + " " + token).strip()

    def record(token, action):
        steps.append({"token": token, "action": action,
                      "ops": " ".join(reversed(ops.to_list())),
                      "output": output})

    for token in tokens:
        if token in PRECEDENCE:                         
            popped = []
            while (not ops.is_empty() and ops.peek() != "("
                   and (PRECEDENCE[ops.peek()] > PRECEDENCE[token]
                        or (PRECEDENCE[ops.peek()] == PRECEDENCE[token]
                            and token not in RIGHT_ASSOCIATIVE))):
                op = ops.pop()
                add(op)
                popped.append(op)
            ops.push(token)
            action = f"Operator: pop {' '.join(popped)} to output, push {token}" if popped \
                else f"Operator: push {token} to ops"
            record(token, action)
        elif token == "(":
            ops.push(token)
            record(token, "Opening bracket: push to ops")
        elif token == ")":
            while not ops.is_empty() and ops.peek() != "(":
                add(ops.pop())
            if ops.is_empty():
                raise ValueError("Unbalanced brackets: extra ')'.")
            ops.pop()                                   
            record(token, "Closing bracket: pop until '(' and discard it")
        else:                                           
            add(token)
            record(token, "Operand: add to output")

    while not ops.is_empty():
        op = ops.pop()
        if op == "(":
            raise ValueError("Unbalanced brackets: missing ')'.")
        add(op)
        record("end", f"End: pop remaining {op} to output")

    return output, steps
